### Installation
* `git clone https://github.com/caleboki/acl.git`

* `cd acl`

* `composer install`

* save the .env.example to .env

* update the .env file with your db credentials

* `php artisan key:generate`