<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('welcome/{locale}', function ($locale) {
    App::setLocale($locale);

    //
});

Route::get('offresStages', ['as'=> 'offresStages.index', 'uses' => 'offresStagesController@index']);
Route::post('offresStages', ['as'=> 'offresStages.store', 'uses' => 'offresStagesController@store']);
Route::get('offresStages/create', ['as'=> 'offresStages.create', 'uses' => 'offresStagesController@create']);
Route::get('offresStages/merci', ['as'=> 'offresStages.merci', 'uses' => 'offresStagesController@merci']);
Auth::routes();

Route::get('/home', 'HomeController@index');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('admin/offresDeStages', ['as'=> 'admin.offresDeStages.index', 'uses' => 'Admin\offresDeStagesController@index']);
Route::post('admin/offresDeStages', ['as'=> 'admin.offresDeStages.store', 'uses' => 'Admin\offresDeStagesController@store']);
Route::get('admin/offresDeStages/create', ['as'=> 'admin.offresDeStages.create', 'uses' => 'Admin\offresDeStagesController@create']);
Route::put('admin/offresDeStages/{offresDeStages}', ['as'=> 'admin.offresDeStages.update', 'uses' => 'Admin\offresDeStagesController@update']);
Route::patch('admin/offresDeStages/{offresDeStages}', ['as'=> 'admin.offresDeStages.update', 'uses' => 'Admin\offresDeStagesController@update']);
Route::delete('admin/offresDeStages/{offresDeStages}', ['as'=> 'admin.offresDeStages.destroy', 'uses' => 'Admin\offresDeStagesController@destroy']);
Route::get('admin/offresDeStages/{offresDeStages}', ['as'=> 'admin.offresDeStages.show', 'uses' => 'Admin\offresDeStagesController@show']);
Route::get('admin/offresDeStages/{offresDeStages}/edit', ['as'=> 'admin.offresDeStages.edit', 'uses' => 'Admin\offresDeStagesController@edit']);

Route::resource('users', 'UserController');

Route::resource('roles', 'RoleController');

Route::resource('permissions', 'PermissionController');

Route::resource('posts', 'PostController');


Route::get('monStage', ['as'=> 'monStage.index', 'uses' => 'monStageController@index']);
Route::get('monStage/{monStage}', ['as'=> 'monStage.show', 'uses' => 'monStageController@show']);