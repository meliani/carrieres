<div class="section">
    <h5>Stages disponibles</h5>
    <div class="row">
@foreach ($offresStages as $offre)
    @if($offre->is_valid)
        <div class="col s12 m6">
          <div class="card blue-grey darken-1 hoverable">
            <div class="card-content white-text">
              <span class="card-title">{{  str_limit($offre->intitule_sujet,70) }}</span>
              <p>{{  str_limit($offre->descriptif, 150) }}</p>
            </div>
            <div class="card-action">
              <a href="{{ route('monStage.show', $offre->id) }}">Détails de l'offre</a>
              <a href="#">Postuler</a>
            </div>
          </div>
        </div>
    @endif
      @endforeach
      </div>
</div>