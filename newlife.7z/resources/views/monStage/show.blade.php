@extends('layouts.ui')

@section('content')

        <ul class="collection with-header">
        <li class="collection-header"><h4>{{  $offresStages->intitule_sujet }}</h4></li>
        <li class="collection-item"><h5>{{  $offresStages->raison_sociale }}</h5></li>
        <li class="collection-item">{{  $offresStages->lieu_de_stage }}</li>
        <li class="collection-item">{{  $offresStages->descriptif }}</li>
        <li class="collection-item">{{  $offresStages->mots_cles }}</li>
        @if($offresStages->document_offre)
        <li class="collection-item">{{  Html::link($offresStages->document_offre) }}</li>
        @endif
      </ul>

@endsection