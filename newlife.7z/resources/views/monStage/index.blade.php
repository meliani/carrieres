@extends('layouts.ui')

@section('content')

                    @include('monStage.liste')

@endsection
