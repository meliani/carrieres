@extends('layouts.app')

@section('content')
<div class="container">
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Nouvelle offre de stage PFE</div>

            <div class="panel-body">


    <div class="content">
        @include('adminlte-templates::common.errors')

        <div class="clearfix"></div>

        @include('flash::message')

        <div class="clearfix"></div>
        <div class="box box-primary">

            <div class="box-body">
                <div class="row">
                    {!! Form::open(['route' => 'offresStages.store', 'files' => true]) !!}

                        @include('offres_stages.fields')

                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
