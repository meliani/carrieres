<table class="table table-responsive" id="offresStages-table">
    <thead>
        <tr>
            <th>Nom Responsable</th>
        <th>Raison Sociale</th>
        <th>Lieu De Stage</th>
        <th>Fonction</th>
        <th>Email</th>
        <th>Intitules Sujets</th>
        <th>Mots Cles</th>
            <th colspan="3">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $offresStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offresStages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $offresStages->nom_responsable; ?></td>
            <td><?php echo $offresStages->raison_sociale; ?></td>
            <td><?php echo $offresStages->lieu_de_stage; ?></td>
            <td><?php echo $offresStages->fonction; ?></td>
            <td><?php echo $offresStages->email; ?></td>
            <td><?php echo $offresStages->intitules_sujets; ?></td>
            <td><?php echo $offresStages->mots_cles; ?></td>
            <td>
                <?php echo Form::open(['route' => ['admin.offresStages.destroy', $offresStages->id], 'method' => 'delete']); ?>

                <div class='btn-group'>
                    <a href="<?php echo route('admin.offresStages.show', [$offresStages->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-eye-open"></i></a>
                    <a href="<?php echo route('admin.offresStages.edit', [$offresStages->id]); ?>" class='btn btn-default btn-xs'><i class="glyphicon glyphicon-edit"></i></a>
                    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                </div>
                <?php echo Form::close(); ?>

            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>