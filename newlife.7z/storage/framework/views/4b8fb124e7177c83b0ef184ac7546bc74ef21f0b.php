<!-- Id Field -->
<div class="form-group">
    <?php echo Form::label('id', 'Id:'); ?>

    <p><?php echo $offresDeStages->id; ?></p>
</div>

<!-- Nom Responsable Field -->
<div class="form-group">
    <?php echo Form::label('nom_responsable', 'Nom Responsable:'); ?>

    <p><?php echo $offresDeStages->nom_responsable; ?></p>
</div>

<!-- Raison Sociale Field -->
<div class="form-group">
    <?php echo Form::label('raison_sociale', 'Raison Sociale:'); ?>

    <p><?php echo $offresDeStages->raison_sociale; ?></p>
</div>

<!-- Lieu De Stage Field -->
<div class="form-group">
    <?php echo Form::label('lieu_de_stage', 'Lieu De Stage:'); ?>

    <p><?php echo $offresDeStages->lieu_de_stage; ?></p>
</div>

<!-- Fonction Field -->
<div class="form-group">
    <?php echo Form::label('fonction', 'Fonction:'); ?>

    <p><?php echo $offresDeStages->fonction; ?></p>
</div>

<!-- Telephone Field -->
<div class="form-group">
    <?php echo Form::label('telephone', 'Telephone:'); ?>

    <p><?php echo $offresDeStages->telephone; ?></p>
</div>

<!-- Email Field -->
<div class="form-group">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo $offresDeStages->email; ?></p>
</div>

<!-- Intitule Sujet Field -->
<div class="form-group">
    <?php echo Form::label('intitule_sujet', 'Intitule Sujet:'); ?>

    <p><?php echo $offresDeStages->intitule_sujet; ?></p>
</div>

<!-- Descriptif Field -->
<div class="form-group">
    <?php echo Form::label('descriptif', 'Descriptif:'); ?>

    <p><?php echo $offresDeStages->descriptif; ?></p>
</div>

<!-- Mots Cles Field -->
<div class="form-group">
    <?php echo Form::label('mots_cles', 'Mots Cles:'); ?>

    <p><?php echo $offresDeStages->mots_cles; ?></p>
</div>

<!-- Document Offre Field -->
<div class="form-group">
    <?php echo Form::label('document_offre', 'Document Offre:'); ?>

    <p><?php echo Html::link($offresDeStages->document_offre); ?></p>
</div>

<!-- Created At Field -->
<div class="form-group">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo $offresDeStages->created_at; ?></p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo $offresDeStages->updated_at; ?></p>
</div>

