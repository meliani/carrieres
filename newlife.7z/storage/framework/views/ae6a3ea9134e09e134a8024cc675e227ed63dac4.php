<?php $__env->startSection('content'); ?>

        <ul class="collection with-header">
        <li class="collection-header"><h4><?php echo e($offresStages->intitule_sujet); ?></h4></li>
        <li class="collection-item"><h5><?php echo e($offresStages->raison_sociale); ?></h5></li>
        <li class="collection-item"><?php echo e($offresStages->lieu_de_stage); ?></li>
        <li class="collection-item"><?php echo e($offresStages->descriptif); ?></li>
        <li class="collection-item"><?php echo e($offresStages->mots_cles); ?></li>
        <?php if($offresStages->document_offre): ?>
        <li class="collection-item"><?php echo e(Html::link($offresStages->document_offre)); ?></li>
        <?php endif; ?>
      </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ui', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>