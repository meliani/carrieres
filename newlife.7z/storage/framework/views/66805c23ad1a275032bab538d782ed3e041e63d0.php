<div class="section">
    <h5>Stages disponibles</h5>
    <div class="row">
<?php $__currentLoopData = $offresStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($offre->is_valid): ?>
        <div class="col s12 m6">
          <div class="card blue-grey darken-1 hoverable">
            <div class="card-content white-text">
              <span class="card-title"><?php echo e(str_limit($offre->intitule_sujet,70)); ?></span>
              <p><?php echo e(str_limit($offre->descriptif, 150)); ?></p>
            </div>
            <div class="card-action">
              <a href="<?php echo e(route('monStage.show', $offre->id)); ?>">Détails de l'offre</a>
              <a href="#">Postuler</a>
            </div>
          </div>
        </div>
    <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
</div>