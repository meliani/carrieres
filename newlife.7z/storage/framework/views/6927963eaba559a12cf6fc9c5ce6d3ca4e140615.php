<!-- Nom Responsable Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nom_responsable', 'Nom du responsable:'); ?>

    <?php echo Form::text('nom_responsable', null, ['class' => 'form-control']); ?>

</div>

<!-- Raison Sociale Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('raison_sociale', 'Raison sociale:'); ?>

    <?php echo Form::text('raison_sociale', null, ['class' => 'form-control']); ?>

</div>

<!-- Lieu De Stage Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('lieu_de_stage', 'Lieu de stage:'); ?>

    <?php echo Form::text('lieu_de_stage', null, ['class' => 'form-control']); ?>

</div>

<!-- Fonction Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('fonction', 'Fonction:'); ?>

    <?php echo Form::text('fonction', null, ['class' => 'form-control']); ?>

</div>

<!-- Tel Field -->
<div class="form-group col-sm-6">
<?php echo Form::label('telephone', 'Téléphone:'); ?>

<?php echo Form::text('telephone', null, ['class' => 'form-control']); ?>

</div>

<!-- Email Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('email', 'Email:'); ?>

    <?php echo Form::email('email', null, ['class' => 'form-control']); ?>

</div>

<!-- Intitule Sujet Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('intitule_sujet', 'Intitule du sujet:'); ?>

    <?php echo Form::textarea('intitule_sujet', null, ['class' => 'form-control']); ?>

</div>

<!-- Descriptif Field -->
<div class="form-group col-sm-12 col-lg-12">
<?php echo Form::label('descriptif', 'Descriptif de l\'offre \\ Prérequis:'); ?>

<?php echo Form::textarea('descriptif', null, ['class' => 'form-control']); ?>

</div>

<!-- Mots Cles Field -->
<div class="form-group col-sm-6">
<?php echo Form::label('mots_cles', 'Mots Clés:'); ?>

<?php echo Form::text('mots_cles', null, ['class' => 'form-control']); ?>

</div>

<!-- Document Offre Field -->
<div class="form-group col-sm-6">
<?php echo Form::label('document_offre', 'Document Offre:'); ?>

<?php echo Form::file('document_offre'); ?>

</div>
<div class="clearfix"></div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Envoyer', ['class' => 'btn btn-primary']); ?>

    <a href="<?php echo route('login'); ?>" class="btn btn-default">Annuler</a>
</div>
