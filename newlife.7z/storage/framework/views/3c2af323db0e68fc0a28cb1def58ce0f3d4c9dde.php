<?php echo Form::open(['route' => ['admin.offresDeStages.destroy', $id], 'method' => 'delete']); ?>


<div class='btn-group'>

    <a href="<?php echo e(route('admin.offresDeStages.show', $id)); ?>" class='btn btn-default btn-xs'>
        <i class="glyphicon glyphicon-eye-open"></i>
    </a>
    <a href="<?php echo e(route('admin.offresDeStages.edit', $id)); ?>" class='btn btn-default btn-xs'>
        <i class="glyphicon glyphicon-edit"></i>
    </a>
    <?php echo Form::button('<i class="glyphicon glyphicon-trash"></i>', [
        'type' => 'submit',
        'class' => 'btn btn-danger btn-xs',
        'onclick' => "return confirm('Are you sure?')"
    ]); ?>

<?php echo Form::close(); ?>


</div>

