<li class="<?php echo e(Request::is('offresDeStages*') ? 'active' : ''); ?>">
    <a href="<?php echo route('admin.offresDeStages.index'); ?>"><i class="fa fa-edit"></i><span>Offres De Stages</span></a>
</li>