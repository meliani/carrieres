<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateoffresStagesRequest;
use App\Http\Requests\UpdateoffresStagesRequest;
use App\Repositories\offresStagesRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class offresStagesController extends AppBaseController
{
    /** @var  offresStagesRepository */
    private $offresStagesRepository;

    public function __construct(offresStagesRepository $offresStagesRepo)
    {
        $this->offresStagesRepository = $offresStagesRepo;
    }

    /**
     * Display a listing of the offresStages.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->offresStagesRepository->pushCriteria(new RequestCriteria($request));
        $offresStages = $this->offresStagesRepository->all();

        return view('offres_stages.create')
            ->with('offresStages', $offresStages);
    }

    /**
     * Show the form for creating a new offresStages.
     *
     * @return Response
     */
    public function create()
    {
        return view('offres_stages.create');
    }
    public function merci()
    {
        return view('offres_stages.merci');
    }
    /**
     * Store a newly created offresStages in storage.
     *
     * @param CreateoffresStagesRequest $request
     *
     * @return Response
     */
    public function store(CreateoffresStagesRequest $request)
    {
        $input = $request->all();

        if($request->hasFile('document_offre'))
        {
            $doc = $request->file('document_offre');
            if ($doc->isValid())
            {
                $path = $doc->storeAs('uploads/',Carbon::now()->format('ymd_hi') .'-'. $doc->getClientOriginalName(),'public');      
                //$path = Storage::disk('uploads')->put('', $doc);
                $input['document_offre'] = 'storage/'.$path;
            }elseif($doc->getError()!='UPLOADERROK')
            Flash::error($doc->getErrorMessage());
        }

        
        
        $offresStages = $this->offresStagesRepository->create($input);

        Flash::success('Offre de stage bien enregistrée.');

        return redirect(route('offresStages.create'))->with('message', 'Votre proposition a été bien enregistrée');
        
    }

    /**
     * Display the specified offresStages.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $offresStages = $this->offresStagesRepository->findWithoutFail($id);

        if (empty($offresStages)) {
            Flash::error('Offres Stages not found');

            return redirect(route('offresStages.index'));
        }

        return view('offres_stages.show')->with('offresStages', $offresStages);
    }

    /**
     * Show the form for editing the specified offresStages.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function edit($id)
    {
        $offresStages = $this->offresStagesRepository->findWithoutFail($id);

        if (empty($offresStages)) {
            Flash::error('Offres Stages not found');

            return redirect(route('offresStages.index'));
        }

        return view('offres_stages.edit')->with('offresStages', $offresStages);
    }

    /**
     * Update the specified offresStages in storage.
     *
     * @param  int              $id
     * @param UpdateoffresStagesRequest $request
     *
     * @return Response
     */
    public function update($id, UpdateoffresStagesRequest $request)
    {
        $offresStages = $this->offresStagesRepository->findWithoutFail($id);

        if (empty($offresStages)) {
            Flash::error('Offres Stages not found');

            return redirect(route('offresStages.index'));
        }

        $offresStages = $this->offresStagesRepository->update($request->all(), $id);

        Flash::success('Offres Stages updated successfully.');

        return redirect(route('offresStages.index'));
    }

    /**
     * Remove the specified offresStages from storage.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function destroy($id)
    {
        $offresStages = $this->offresStagesRepository->findWithoutFail($id);

        if (empty($offresStages)) {
            Flash::error('Offres Stages not found');

            return redirect(route('offresStages.index'));
        }

        $this->offresStagesRepository->delete($id);

        Flash::success('Offres Stages deleted successfully.');

        return redirect(route('offresStages.index'));
    }
}

