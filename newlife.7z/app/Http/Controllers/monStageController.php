<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateoffresStagesRequest;
use App\Http\Requests\UpdateoffresStagesRequest;
use App\Repositories\offresStagesRepository;
use App\Http\Controllers\AppBaseController;
use Illuminate\Http\Request;
use Flash;
use Prettus\Repository\Criteria\RequestCriteria;
use Response;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class monStageController extends AppBaseController
{
    /** @var  offresStagesRepository */
    private $offresStagesRepository;

    public function __construct(offresStagesRepository $offresStagesRepo)
    {
        $this->middleware(['auth']);        
        $this->offresStagesRepository = $offresStagesRepo;
    }

    /**
     * Display a listing of the offresStages.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        $this->offresStagesRepository->pushCriteria(new RequestCriteria($request));
        $offresStages = $this->offresStagesRepository->all();

        return view('monStage.index')
            ->with('offresStages', $offresStages);
    }


    /**
     * Display the specified offresStages.
     *
     * @param  int $id
     *
     * @return Response
     */
    public function show($id)
    {
        $offresStages = $this->offresStagesRepository->findWithoutFail($id);

        if (empty($offresStages)) {
            Flash::error('Offres Stages not found');

            return redirect(route('monStage.index'));
        }

        return view('monStage.show')->with('offresStages', $offresStages);
    }

 
}

