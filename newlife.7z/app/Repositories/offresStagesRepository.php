<?php

namespace App\Repositories;

use App\Models\offresStages;
use InfyOm\Generator\Common\BaseRepository;

/**
 * Class offresStagesRepository
 * @package App\Repositories\Admin
 * @version November 14, 2017, 11:11 am UTC
 *
 * @method offresStages findWithoutFail($id, $columns = ['*'])
 * @method offresStages find($id, $columns = ['*'])
 * @method offresStages first($columns = ['*'])
*/
class offresStagesRepository extends BaseRepository
{
    /**
     * @var array
     */
    protected $fieldSearchable = [
        'nom_responsable',
        'raison_sociale',
        'lieu_de_stage',
        'fonction',
        'telephone',
        'email',
        'intitules_sujets',
        'mots_cles',
        'document_offre'
    ];

    /**
     * Configure the Model
     **/
    public function model()
    {
        return offresStages::class;
    }
}
